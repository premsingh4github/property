frontend-edit-profile
=====================

Wordpress plugin to add profile edit to your frontend with shortcode

for more information 
http://wordpress.org/plugins/frontend-edit-profile/

Need help to translate this plugin,
send your translate to dev@dulabs.com
