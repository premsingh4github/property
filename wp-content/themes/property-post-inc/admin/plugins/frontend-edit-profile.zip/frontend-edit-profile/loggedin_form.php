<ul>
	<li><a href="<?php echo esc_attr(get_option('fep_loginurl'));?>"><?php _e("Your Profile");?></a></li>
	<li><a href="<?php echo esc_attr(get_option('fep_logouturl'));?>"><?php _e("Logout");?></a></li>
</ul>
		